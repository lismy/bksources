setmqaut -m PMDW4 -n QLP.MX3.FEESIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
setmqaut -m PMDW4 -n QLP.MX3.FIXIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
setmqaut -m PMDW4 -n QL.MX3.FIXIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
setmqaut -m PMDW4 -n QL.MX3.FEESIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;