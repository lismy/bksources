setmqaut -m PMDW2 -n QLP.MX3.FEESIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
setmqaut -m PMDW2 -n QLP.MX3.FIXIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
setmqaut -m PMDW2 -n QL.MX3.FIXIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
setmqaut -m PMDW2 -n QL.MX3.FEESIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;