setmqaut -m PMDW3 -n QLP.MX3.FEESIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
setmqaut -m PMDW3 -n QLP.MX3.FIXIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
setmqaut -m PMDW3 -n QL.MX3.FIXIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
setmqaut -m PMDW3 -n QL.MX3.FEESIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;