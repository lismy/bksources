


DROP PACKAGE "MUREX"."PKG_MUREX_READ";
/
--------------------------------------------------------
--  DDL for Package PKG_MUREX_READ
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "MUREX"."PKG_MUREX_READ" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  PROCEDURE sp_check_contract(
    contractid IN VARCHAR2, 
    check_out OUT int);
  
  PROCEDURE sp_check_trade(
    tradeid IN VARCHAR2, 
    check_out OUT int);
    
  PROCEDURE sp_show_events (
    servicecode IN VARCHAR, 
    listaeventoprod OUT SYS_REFCURSOR);
    
  PROCEDURE sp_check_unique (
      event IN transaction_log.orig_event%TYPE, 
      contractid IN transaction_log.contract_id%TYPE,
      tradeid IN transaction_log.trade_id%TYPE,
      tradeversion IN transaction_log.trade_version%TYPE,
      check_out OUT int);
      
  PROCEDURE sp_mostrar_parametronegocio (
        servicecode IN VARCHAR,
        listaparametronegocio OUT   SYS_REFCURSOR);
        
  PROCEDURE sp_check_event_start (
    contractid IN transaction_log.contract_id%TYPE,
    check_out OUT int);
    
  PROCEDURE sp_show_pending (
        pi_contractid IN transaction_log.contract_id%TYPE, 
        po_listpending OUT SYS_REFCURSOR);
 
  PROCEDURE sp_list_parameters_generic (
    servicecode IN VARCHAR, 
    listparameters OUT SYS_REFCURSOR);

END PKG_MUREX_READ;

/
--------------------------------------------------------
--  DDL for Package Body PKG_MUREX_READ
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "MUREX"."PKG_MUREX_READ" AS

  PROCEDURE sp_check_contract(contractid IN VARCHAR2, check_out OUT int) AS
  total int;
  BEGIN
    SELECT COUNT(CONTRACT_ID) into total FROM TRANSACTION_LOG WHERE CONTRACT_ID = contractid;
    -- necesitaremos el conteo ?
    if total != 0 then
    check_out := 0;
    else
    check_out := 1;
    end if; 
  END sp_check_contract;

  PROCEDURE sp_check_trade(tradeid IN VARCHAR2, check_out OUT int) AS
  total int;
  BEGIN
    SELECT COUNT(TRADE_ID) into total FROM TRANSACTION_LOG WHERE TRADE_ID = tradeid;
    -- necesitaremos el conteo ?
    if total != 0 then
    check_out := 0;
    else
    check_out := 1;
    end if; 
  END sp_check_trade;
  
  PROCEDURE sp_show_events (servicecode IN VARCHAR, listaeventoprod OUT SYS_REFCURSOR) AS
  BEGIN
   OPEN listaeventoprod
   FOR SELECT
            E.ORIG_EVENT, E.EVENT_TYPE, LISTAGG(CONCAT(CONCAT(P.CODE,':'),P.FLEX), '|') WITHIN GROUP (ORDER BY EP.ID) AS PRODUCTS 
    FROM EVENT_PRODUCT EP 
    JOIN PRODUCT P ON EP.ID_PRODUCT = P.ID
    JOIN EVENT E ON EP.ID_EVENT = E.ID
    WHERE EP.STATUS = 'A'
    GROUP BY E.ORIG_EVENT, E.EVENT_TYPE;

    EXCEPTION
        WHEN OTHERS THEN
            raise_application_error(-20299, '1&');
  END sp_show_events;
  
  
  --Obtiene la cantidad de mensajes registrados previamente en la
  --tabla TRANSACTION_LOG por el campo CONTRACT_ID,TRADE_ID,TRADE_VERSION
  PROCEDURE sp_check_unique (
      event IN transaction_log.orig_event%TYPE, 
      contractid IN transaction_log.contract_id%TYPE,
      tradeid IN transaction_log.trade_id%TYPE,
      tradeversion IN transaction_log.trade_version%TYPE,
      check_out OUT int) AS
      BEGIN
      
      SELECT COUNT(CONTRACT_ID) INTO check_out FROM 
      TRANSACTION_LOG WHERE 
        ORIG_EVENT = event
        AND CONTRACT_ID = contractid
        AND TRADE_ID = tradeid
        AND TRADE_VERSION = tradeversion;
        
   END sp_check_unique;

  PROCEDURE sp_mostrar_parametronegocio (
        servicecode IN VARCHAR,
        listaparametronegocio OUT   SYS_REFCURSOR
    ) AS
    BEGIN
        OPEN listaparametronegocio 
            FOR SELECT
                r.id,
                t.name,
                r.id_rule_owner,
                r.perfil
                    FROM
                    rules r
                    JOIN tag t ON r.id_tag = t.id
                    WHERE r.service_code = servicecode;

    EXCEPTION
        WHEN OTHERS THEN
            raise_application_error(-20299, '1&');
    END sp_mostrar_parametronegocio;

    PROCEDURE sp_check_event_start (
        contractid IN transaction_log.contract_id%TYPE,
        check_out OUT int) AS
        BEGIN
        
        SELECT COUNT(CONTRACT_ID) into check_out from transaction_log where 
        ORIG_EVENT ='Insert' and EVENT_TYPE IS NULL OR (ORIG_EVENT = 'Modify' and EVENT_TYPE = 'Refresh') and status = 'SEND' 
        AND CONTRACT_ID = contractid; 
        
        END sp_check_event_start;
    
    --OBTIENE EL LISTADO DE EVENTOS EN ESTADO PENDIENTE
    PROCEDURE sp_show_pending (
        pi_contractid IN transaction_log.contract_id%TYPE, 
        po_listpending OUT SYS_REFCURSOR) AS
        BEGIN 
        
        OPEN po_listpending
            FOR SELECT MESSAGE_ID, CONTENT_XML FROM 
            TRANSACTION_LOG 
            WHERE CONTRACT_ID = pi_contractid AND status = 'PENDING' 
            AND ORIG_EVENT <> 'Insert' AND ORIG_EVENT <> 'Modify'
            ORDER BY TRADE_VERSION, TRADE_DATE;

    EXCEPTION
        WHEN OTHERS THEN
            raise_application_error(-20299, '1&');
    END sp_show_pending;
    
    -- Author: Anthonny Caro
    -- Lista parametros genericos : Las colas de cada producto
    PROCEDURE sp_list_parameters_generic (
        servicecode IN VARCHAR, 
        listparameters OUT SYS_REFCURSOR) AS
    BEGIN
        OPEN listparameters
            FOR SELECT
                PG.FIELD, PG.VALUE
        FROM PARAMETERS_GENERIC PG 
        WHERE PG.SERVICE = servicecode AND PG.STATUS = 'A';
    EXCEPTION
        WHEN OTHERS THEN
            raise_application_error(-20299, '1&');
    END sp_list_parameters_generic;
    
END PKG_MUREX_READ;

/

grant execute on MUREX.PKG_MUREX_READ 		to MUREX;