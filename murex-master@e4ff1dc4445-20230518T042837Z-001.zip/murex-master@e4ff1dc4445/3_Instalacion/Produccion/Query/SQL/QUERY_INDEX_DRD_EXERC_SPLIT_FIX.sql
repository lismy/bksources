--Creacion del campo CONTENT_XML_EDIT(DOBLE EXERCISE)
ALTER TABLE MUREX.TRANSACTION_LOG ADD CONTENT_XML_EDIT CLOB;
COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."CONTENT_XML_EDIT" IS 'Campo que agrega la trama editada que se envia a Spectrum';
COMMIT;
/
--DRD
Insert into MUREX.PRODUCT(ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('24','IRD:LN_BR:','Producto Estructurado DRD',null,'3','A',null);
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('232','1','24','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('233','11','24','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('234','3','24','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('235','4','24','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('236','26','24','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('237','2','24','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('238','10','24','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('239','15','24','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('240','12','24','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('260','8','24','A');

Insert into MUREX.PARAMETERS_GENERIC (ID,FIELD,VALUE,STATUS,SERVICE) values ('18','IRDLN_BR','QL.MX3.FEESIRDLNBR.RQ','A','10302');
Insert into MUREX.PARAMETERS_GENERIC (ID,FIELD,VALUE,STATUS,SERVICE) values ('19','IRDLN_BRFIXING','QL.MX3.FIXIRDLNBR.RQ','A','10302');
COMMIT;

--SPLIT
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('27','Restructure','Descripción del evento','A','Restructure','CA - Split');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('241','27','1','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('242','27','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('243','27','3','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('244','27','4','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('245','27','5','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('246','27','6','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('247','27','7','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('248','27','8','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('249','27','9','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('250','27','10','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('251','27','11','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('252','27','12','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('253','27','13','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('254','27','14','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('255','27','15','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('256','27','16','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('257','27','17','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('258','27','18','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('259','27','19','A');
COMMIT;

--INDEX TRANSITION
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('28','Restructure','Descripción del evento','A','Restructure','Index Transition');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('261','28','1','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('262','28','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('263','28','3','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('264','28','4','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('265','28','5','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('266','28','6','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('267','28','7','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('268','28','8','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('269','28','9','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('270','28','10','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('271','28','11','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('272','28','12','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('273','28','13','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('274','28','14','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('275','28','15','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('276','28','16','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('277','28','17','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('278','28','18','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('279','28','19','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('280','28','20','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('281','28','21','A');
COMMIT;

/
--------------------------------------------------------
--  DDL for Package PKG_MUREX_INS_UPDT
--------------------------------------------------------

--------------------------------------------------------
--  DDL for Package PKG_MUREX_INS_UPDT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "MUREX"."PKG_MUREX_INS_UPDT" AS 

  PROCEDURE sp_update_status_msg (piv_message_id IN transaction_log.message_id%TYPE, 
                                  piv_status IN transaction_log.status%TYPE,
                                  piv_status_description IN transaction_log.status_description%TYPE,
                                  pov_code_resp OUT VARCHAR2,
                                  pov_msg_resp OUT VARCHAR2);
  
  PROCEDURE sp_register_log (piv_id_audit_hub IN transaction_log.id_audit_hub%TYPE, 
                             picb_content IN transaction_log.content_xml%TYPE, 
                             pov_code_resp OUT VARCHAR2, 
                             pov_msg_resp OUT VARCHAR2);
    
  PROCEDURE sp_update_log (piv_id_audit_hub IN transaction_log.id_audit_hub%TYPE, 
                           piv_message_id IN transaction_log.message_id%TYPE, 
                           piv_orig_event IN transaction_log.orig_event%TYPE,
                           piv_trade_id IN transaction_log.trade_id%TYPE,
                           piv_event_type IN transaction_log.event_type%TYPE,
                           piv_contract_id IN transaction_log.contract_id%TYPE,
                           piv_trade_status IN transaction_log.trade_status%TYPE,
                           piv_trade_date IN transaction_log.trade_date%TYPE,
                           pic_trade_version IN transaction_log.trade_version%TYPE,
                           piv_product IN transaction_log.product%TYPE,
                           pic_status IN transaction_log.status%TYPE,
						   pic_event_cancellation IN transaction_log.event_cancellation%TYPE,
                           pov_code_resp OUT VARCHAR2, 
                           pov_msg_resp OUT VARCHAR2); 
						   
  PROCEDURE sp_update_contentxml_edit (piv_id_audit_hub IN transaction_log.id_audit_hub%TYPE, 
                             picb_content_edit IN transaction_log.content_xml_edit%TYPE, 
                             pov_code_resp OUT VARCHAR2, 
                             pov_msg_resp OUT VARCHAR2);						   

END PKG_MUREX_INS_UPDT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_MUREX_INS_UPDT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "MUREX"."PKG_MUREX_INS_UPDT" AS
--SP que actualiza el estado del mensaje
  PROCEDURE sp_update_status_msg (piv_message_id IN transaction_log.message_id%TYPE, 
                                  piv_status IN transaction_log.status%TYPE,
                                  piv_status_description IN transaction_log.status_description%TYPE,
                                  pov_code_resp OUT VARCHAR2,
                                  pov_msg_resp OUT VARCHAR2) AS 
  BEGIN
    UPDATE TRANSACTION_LOG
    SET STATUS = piv_status,
    STATUS_DESCRIPTION = piv_status_description
    WHERE MESSAGE_ID = piv_message_id;  
    COMMIT;
    pov_code_resp := SQLCODE;
    pov_msg_resp := 'ACTUALIZACION EXITOSA';
  EXCEPTION 
    WHEN OTHERS THEN
        pov_code_resp := SQLCODE;
        pov_msg_resp := 'ERROR AL EJECUTAR [sp_update_status_msg] - ' || SQLERRM;
  END sp_update_status_msg;
  
  --SP que salvaguarda el mensaje(XML) y el campo id_audit_hub en la tabla TRANSACTION_LOG 
  PROCEDURE sp_register_log (piv_id_audit_hub IN transaction_log.id_audit_hub%type, 
                             picb_content IN transaction_log.content_xml%type, 
                             pov_code_resp OUT VARCHAR2, 
                             pov_msg_resp OUT VARCHAR2) AS
  BEGIN
    INSERT INTO TRANSACTION_LOG (ID_AUDIT_HUB, 
                                 CONTENT_XML)
    VALUES (piv_id_audit_hub, 
            picb_content);
    COMMIT;
    pov_code_resp := SQLCODE;
    pov_msg_resp := 'REGISTRO EXITOSO';
  EXCEPTION 
        WHEN OTHERS THEN
            pov_code_resp := SQLCODE;
            pov_msg_resp := 'ERROR AL EJECUTAR [sp_register_new] - ' || SQLERRM;
  END sp_register_log;
  
  
  --SP que actualiza la tabla del mensaje con sus campos adicionales, basandose
  --en el campo ID_AUDIT_HUB, guardado previamente con sp_register_log.
  PROCEDURE sp_update_log (piv_id_audit_hub IN transaction_log.id_audit_hub%type,
                           piv_message_id IN transaction_log.message_id%type, 
                           piv_orig_event IN transaction_log.orig_event%type,
                           piv_trade_id IN transaction_log.trade_id%type,
                           piv_event_type IN transaction_log.event_type%type,
                           piv_contract_id IN transaction_log.contract_id%type,
                           piv_trade_status IN transaction_log.trade_status%type,
                           piv_trade_date IN transaction_log.trade_date%type,
                           pic_trade_version IN transaction_log.trade_version%type,
                           piv_product IN transaction_log.product%type,
                           pic_status IN transaction_log.status%type,
						   pic_event_cancellation IN transaction_log.event_cancellation%type,
                           pov_code_resp OUT VARCHAR2, 
                           pov_msg_resp OUT VARCHAR2) AS 
  BEGIN
    UPDATE TRANSACTION_LOG
    SET MESSAGE_ID = piv_message_id,
        ORIG_EVENT = piv_orig_event,
        TRADE_ID = piv_trade_id,
        EVENT_TYPE = piv_event_type,
        CONTRACT_ID = piv_contract_id,
        TRADE_STATUS = piv_trade_status,
        TRADE_DATE = piv_trade_date,
        TRADE_VERSION = pic_trade_version,
        PRODUCT = piv_product,
        STATUS = pic_status,
		EVENT_CANCELLATION = pic_event_cancellation
    WHERE ID_AUDIT_HUB = piv_id_audit_hub;  
    COMMIT;
    pov_code_resp := SQLCODE;
    pov_msg_resp := 'ACTUALIZACION EXITOSA';
  EXCEPTION 
    WHEN OTHERS THEN
        pov_code_resp := SQLCODE;
        pov_msg_resp := 'ERROR AL EJECUTAR [sp_update_log] - ' || SQLERRM;
  END sp_update_log;  
  
   PROCEDURE sp_update_contentxml_edit (piv_id_audit_hub IN transaction_log.id_audit_hub%type, 
                             picb_content_edit IN transaction_log.content_xml_edit%type, 
                             pov_code_resp OUT VARCHAR2, 
                             pov_msg_resp OUT VARCHAR2) AS
  BEGIN
    UPDATE TRANSACTION_LOG
    SET CONTENT_XML_EDIT = picb_content_edit
    WHERE ID_AUDIT_HUB = piv_id_audit_hub;  
    COMMIT;
    pov_code_resp := SQLCODE;
    pov_msg_resp := 'REGISTRO EXITOSO';
  EXCEPTION 
        WHEN OTHERS THEN
            pov_code_resp := SQLCODE;
            pov_msg_resp := 'ERROR AL EJECUTAR [sp_update_contentxml_edit] - ' || SQLERRM;
  END sp_update_contentxml_edit; 
  
  END PKG_MUREX_INS_UPDT;
/
grant execute on MUREX.PKG_MUREX_INS_UPDT 	to APP_MUREX;
