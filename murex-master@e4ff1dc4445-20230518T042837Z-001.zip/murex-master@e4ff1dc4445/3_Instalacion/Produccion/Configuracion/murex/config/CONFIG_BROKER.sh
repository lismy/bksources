#!/bin/bash
work_dir=$1
mqsisetdbparms -w /opt/IBM/ace-11.0.0.11/server/workdir/$work_dir/ -n APP_HUBACE -u APP_HUBACE  -p VUog8hQ32UgG4S
mqsisetdbparms -w /opt/IBM/ace-11.0.0.11/server/workdir/$work_dir/ -n MUREX -u MUREX  -p SGg14nmCHJlnrgxO

