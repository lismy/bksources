ALTER TABLE MUREX.TRANSACTION_LOG ADD EVENT_CANCELLATION VARCHAR(20 BYTE);
COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."EVENT_CANCELLATION" IS 'Campo que permite validar la cancelacion de una operacion migrada';
COMMIT;


/
--------------------------------------------------------
--  DDL for Package PKG_MUREX_INS_UPDT
--------------------------------------------------------

--------------------------------------------------------
--  DDL for Package PKG_MUREX_INS_UPDT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "MUREX"."PKG_MUREX_INS_UPDT" AS 

  PROCEDURE sp_update_status_msg (piv_message_id IN transaction_log.message_id%TYPE, 
                                  piv_status IN transaction_log.status%TYPE,
                                  piv_status_description IN transaction_log.status_description%TYPE,
                                  pov_code_resp OUT VARCHAR2,
                                  pov_msg_resp OUT VARCHAR2);
  
  PROCEDURE sp_register_log (piv_id_audit_hub IN transaction_log.id_audit_hub%TYPE, 
                             picb_content IN transaction_log.content_xml%TYPE, 
                             pov_code_resp OUT VARCHAR2, 
                             pov_msg_resp OUT VARCHAR2);
    
  PROCEDURE sp_update_log (piv_id_audit_hub IN transaction_log.id_audit_hub%TYPE, 
                           piv_message_id IN transaction_log.message_id%TYPE, 
                           piv_orig_event IN transaction_log.orig_event%TYPE,
                           piv_trade_id IN transaction_log.trade_id%TYPE,
                           piv_event_type IN transaction_log.event_type%TYPE,
                           piv_contract_id IN transaction_log.contract_id%TYPE,
                           piv_trade_status IN transaction_log.trade_status%TYPE,
                           piv_trade_date IN transaction_log.trade_date%TYPE,
                           pic_trade_version IN transaction_log.trade_version%TYPE,
                           piv_product IN transaction_log.product%TYPE,
                           pic_status IN transaction_log.status%TYPE,
						   pic_event_cancellation IN transaction_log.event_cancellation%TYPE,
                           pov_code_resp OUT VARCHAR2, 
                           pov_msg_resp OUT VARCHAR2);                          

END PKG_MUREX_INS_UPDT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_MUREX_INS_UPDT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "MUREX"."PKG_MUREX_INS_UPDT" AS
--SP que actualiza el estado del mensaje
  PROCEDURE sp_update_status_msg (piv_message_id IN transaction_log.message_id%TYPE, 
                                  piv_status IN transaction_log.status%TYPE,
                                  piv_status_description IN transaction_log.status_description%TYPE,
                                  pov_code_resp OUT VARCHAR2,
                                  pov_msg_resp OUT VARCHAR2) AS 
  BEGIN
    UPDATE TRANSACTION_LOG
    SET STATUS = piv_status,
    STATUS_DESCRIPTION = piv_status_description
    WHERE MESSAGE_ID = piv_message_id;  
    COMMIT;
    pov_code_resp := SQLCODE;
    pov_msg_resp := 'ACTUALIZACION EXITOSA';
  EXCEPTION 
    WHEN OTHERS THEN
        pov_code_resp := SQLCODE;
        pov_msg_resp := 'ERROR AL EJECUTAR [sp_update_status_msg] - ' || SQLERRM;
  END sp_update_status_msg;
  
  --SP que salvaguarda el mensaje(XML) y el campo id_audit_hub en la tabla TRANSACTION_LOG 
  PROCEDURE sp_register_log (piv_id_audit_hub IN transaction_log.id_audit_hub%type, 
                             picb_content IN transaction_log.content_xml%type, 
                             pov_code_resp OUT VARCHAR2, 
                             pov_msg_resp OUT VARCHAR2) AS
  BEGIN
    INSERT INTO TRANSACTION_LOG (ID_AUDIT_HUB, 
                                 CONTENT_XML)
    VALUES (piv_id_audit_hub, 
            picb_content);
    COMMIT;
    pov_code_resp := SQLCODE;
    pov_msg_resp := 'REGISTRO EXITOSO';
  EXCEPTION 
        WHEN OTHERS THEN
            pov_code_resp := SQLCODE;
            pov_msg_resp := 'ERROR AL EJECUTAR [sp_register_new] - ' || SQLERRM;
  END sp_register_log;
  
  
  --SP que actualiza la tabla del mensaje con sus campos adicionales, basandose
  --en el campo ID_AUDIT_HUB, guardado previamente con sp_register_log.
  PROCEDURE sp_update_log (piv_id_audit_hub IN transaction_log.id_audit_hub%type,
                           piv_message_id IN transaction_log.message_id%type, 
                           piv_orig_event IN transaction_log.orig_event%type,
                           piv_trade_id IN transaction_log.trade_id%type,
                           piv_event_type IN transaction_log.event_type%type,
                           piv_contract_id IN transaction_log.contract_id%type,
                           piv_trade_status IN transaction_log.trade_status%type,
                           piv_trade_date IN transaction_log.trade_date%type,
                           pic_trade_version IN transaction_log.trade_version%type,
                           piv_product IN transaction_log.product%type,
                           pic_status IN transaction_log.status%type,
						   pic_event_cancellation IN transaction_log.event_cancellation%type,
                           pov_code_resp OUT VARCHAR2, 
                           pov_msg_resp OUT VARCHAR2) AS 
  BEGIN
    UPDATE TRANSACTION_LOG
    SET MESSAGE_ID = piv_message_id,
        ORIG_EVENT = piv_orig_event,
        TRADE_ID = piv_trade_id,
        EVENT_TYPE = piv_event_type,
        CONTRACT_ID = piv_contract_id,
        TRADE_STATUS = piv_trade_status,
        TRADE_DATE = piv_trade_date,
        TRADE_VERSION = pic_trade_version,
        PRODUCT = piv_product,
        STATUS = pic_status,
		EVENT_CANCELLATION = pic_event_cancellation
    WHERE ID_AUDIT_HUB = piv_id_audit_hub;  
    COMMIT;
    pov_code_resp := SQLCODE;
    pov_msg_resp := 'ACTUALIZACION EXITOSA';
  EXCEPTION 
    WHEN OTHERS THEN
        pov_code_resp := SQLCODE;
        pov_msg_resp := 'ERROR AL EJECUTAR [sp_update_log] - ' || SQLERRM;
  END sp_update_log;  
  
  END PKG_MUREX_INS_UPDT;
/
grant execute on MUREX.PKG_MUREX_INS_UPDT 	to MUREX;