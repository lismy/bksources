--------------------------------------------------------
-- Archivo creado  - -diciembre-16-2020   
-- Archivo actualizado  - -abril-08-2020   
--------------------------------------------------------
--------------------------------------------------------
-- Eliminando tablas y package  - 16/03/2021   
--------------------------------------------------------
DROP TABLE "MUREX"."AUDIT_ERROR";
--DROP TABLE "MUREX"."MATRIX_TAG";
DROP TABLE "MUREX"."EVENT_PRODUCT";
--DROP TABLE "MUREX"."MATRIX_PRODUCT";
DROP TABLE "MUREX"."NAMESPACE";
DROP TABLE "MUREX"."PRODUCT";
DROP TABLE "MUREX"."RULES";
DROP TABLE "MUREX"."TAG";
--DROP TABLE "MUREX"."TAG_NAMESPACE";
DROP TABLE "MUREX"."TRANSACTION_LOG";
DROP TABLE "MUREX"."PARAMETERS_GENERIC";
DROP TABLE "MUREX"."FAMILY";
--DROP TABLE "MUREX"."MATRIX_RULES";
DROP TABLE "MUREX"."EVENT";
DROP PACKAGE "MUREX"."PKG_MUREX_DELETE";
DROP PACKAGE "MUREX"."PKG_MUREX_INS_UPDT";
DROP PACKAGE "MUREX"."PKG_MUREX_READ";

--------------------------------------------------------
--  DDL for Table AUDIT_ERROR
--------------------------------------------------------
  CREATE TABLE "MUREX"."AUDIT_ERROR" 
   (	"ID" NUMBER, 
	"ORIGEVENT" VARCHAR2(50 BYTE), 
	"TRADEID" NUMBER, 
	"MESSAGE_ID" VARCHAR2(300 BYTE), 
	"HANDLER_MESSAGE" VARCHAR2(300 BYTE), 
	"ID_AUDIT_HUB" VARCHAR2(100 BYTE)
   );
  COMMIT;
--------------------------------------------------------
--  DDL for Table EVENT
--------------------------------------------------------

  CREATE TABLE "MUREX"."EVENT" 
   (	"ID" NUMBER, 
	"NAME" VARCHAR2(100 BYTE), 
	"DESCRIPTION" VARCHAR2(300 BYTE), 
	"STATUS" CHAR(1 BYTE), 
	"ORIG_EVENT" VARCHAR2(100 BYTE), 
	"EVENT_TYPE" VARCHAR2(100 BYTE)
   );
   COMMIT;
--------------------------------------------------------
--  DDL for Table EVENT_PRODUCT
--------------------------------------------------------

  CREATE TABLE "MUREX"."EVENT_PRODUCT" 
   (	"ID" NUMBER, 
	"ID_EVENT" NUMBER, 
	"ID_PRODUCT" NUMBER, 
	"STATUS" CHAR(1 BYTE)
   );
   COMMIT;
--------------------------------------------------------
--  DDL for Table FAMILY
--------------------------------------------------------

  CREATE TABLE "MUREX"."FAMILY" 
   (	"ID" NUMBER, 
	"NAME" VARCHAR2(100 BYTE), 
	"DESCRIPTION" VARCHAR2(300 BYTE), 
	"STATUS" CHAR(1 BYTE)
   );
   COMMIT;
--------------------------------------------------------
--  DDL for Table NAMESPACE
--------------------------------------------------------

  CREATE TABLE "MUREX"."NAMESPACE" 
   (	"ID" NUMBER, 
	"NAME" VARCHAR2(100 BYTE), 
	"DESCRIPTION" VARCHAR2(200 BYTE)
   );
   COMMIT;
--------------------------------------------------------
--  DDL for Table PRODUCT
--------------------------------------------------------

  CREATE TABLE "MUREX"."PRODUCT" 
   (	"ID" NUMBER, 
	"CODE" VARCHAR2(50 BYTE), 
	"DESCRIPTION" VARCHAR2(200 BYTE), 
	"ID_PRODCUT_OWNER" NUMBER, 
	"ID_FAMILY" NUMBER, 
	"STATUS" CHAR(1 BYTE), 
	"FLEX" VARCHAR2(50 BYTE)
   );
   COMMIT;
--------------------------------------------------------
--  DDL for Table RULES
--------------------------------------------------------

  CREATE TABLE "MUREX"."RULES" 
   (	"ID_TAG" NUMBER, 
	"PERFIL" VARCHAR2(100 BYTE), 
	"SERVICE_CODE" VARCHAR2(20 BYTE), 
	"ID" VARCHAR2(10 BYTE), 
	"ID_RULE_OWNER" VARCHAR2(10 BYTE)
   );
   COMMIT;
--------------------------------------------------------
--  DDL for Table TAG
--------------------------------------------------------

  CREATE TABLE "MUREX"."TAG" 
   (	"ID" NUMBER, 
	"NAME" VARCHAR2(50 BYTE), 
	"DESCRIPTION" VARCHAR2(200 BYTE), 
	"STATUS" CHAR(1 BYTE)
   );
   COMMIT;
 --------------------------------------------------------
--  DDL for Table PARAMETERS_GENERIC
-------------------------------------------------------- 
    CREATE TABLE "MUREX"."PARAMETERS_GENERIC" 
   (	"ID" NUMBER NOT NULL ENABLE, 
	"FIELD" VARCHAR2(20 BYTE), 
	"VALUE" VARCHAR2(40 BYTE), 
	"STATUS" CHAR(1 BYTE), 
	"SERVICE" NUMBER
   );

   COMMENT ON COLUMN "MUREX"."PARAMETERS_GENERIC"."ID" IS 'identifier of each record';
   COMMENT ON COLUMN "MUREX"."PARAMETERS_GENERIC"."FIELD" IS 'description of the field to reference';
   COMMENT ON COLUMN "MUREX"."PARAMETERS_GENERIC"."VALUE" IS '
value of each field';
   COMMENT ON COLUMN "MUREX"."PARAMETERS_GENERIC"."STATUS" IS '
record status';
   COMMENT ON COLUMN "MUREX"."PARAMETERS_GENERIC"."SERVICE" IS 'service code';
    COMMIT;
--------------------------------------------------------
--  DDL for Table TRANSACTION_LOG
--------------------------------------------------------
  CREATE TABLE "MUREX"."TRANSACTION_LOG" 
   (	"MESSAGE_ID" VARCHAR2(100 BYTE), 
	"ORIG_EVENT" VARCHAR2(50 BYTE), 
	"TRADE_ID" VARCHAR2(50 BYTE), 
	"CONTENT_XML" CLOB, 
	"EVENT_TYPE" VARCHAR2(50 BYTE), 
	"ID_AUDIT_HUB" VARCHAR2(100 BYTE), 
	"CONTRACT_ID" VARCHAR2(50 BYTE), 
	"TRADE_STATUS" VARCHAR2(20 BYTE), 
	"TRADE_DATE" VARCHAR2(100 BYTE), 
	"TRADE_VERSION" VARCHAR2(50 BYTE), 
	"PRODUCT" VARCHAR2(50 BYTE), 
	"REG_DATE" TIMESTAMP (6) DEFAULT SYSDATE, 
	"STATUS" VARCHAR2(20 BYTE), 
	"ID" NUMBER GENERATED ALWAYS AS IDENTITY MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 CACHE 20 NOORDER  NOCYCLE , 
	"STATUS_DESCRIPTION" VARCHAR2(100 BYTE)
   );

   COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."MESSAGE_ID" IS 'Id del mensaje (Message_id desde el FPML)';
   COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."ORIG_EVENT" IS 'Evento Origen (Originating_Event desde el FPML)';
   COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."TRADE_ID" IS 'N�mero del Trade (Trade Internal desde el FPML)';
   COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."CONTENT_XML" IS 'Contenido completo del FPML (XML)';
   COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."EVENT_TYPE" IS 'Tipo de Evento (event_type desde el FPML)';
   COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."ID_AUDIT_HUB" IS 'ID generado por el Queue Manager';
   COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."CONTRACT_ID" IS 'N�mero de contrato (Contract Root desde el FPML)';
   COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."TRADE_DATE" IS 'Fecha del Trade (Se encuentra en la etiqueta creationTimestamp del Header en el FPML)';
   COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."TRADE_VERSION" IS 'Versi�n del Trade (1,2,3,4...)';
   COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."PRODUCT" IS 'Producto del Evento (de forma compuesta Ej. CURR:OPT:FLEX)';
   COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."REG_DATE" IS 'Fecha del registro en la tabla';
   COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."STATUS" IS 'Estado de la transacci�n';
   COMMENT ON COLUMN "MUREX"."TRANSACTION_LOG"."STATUS_DESCRIPTION" IS 'Descripci�n del estado';
    COMMIT;
REM INSERTING into MUREX.AUDIT_ERROR
SET DEFINE OFF;
REM INSERTING into MUREX.EVENT
SET DEFINE OFF;
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('2','Counterparty Assignment','Descripci�n del evento','A','Assignment','Total Novation - remaining party');
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('3','Cancel','Descripci�n del evento','A','Cancel','Operations Error');
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('4','Cancel and Reissue','Descripci�n del evento','A','CancelReissue','Modification');
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('5','Counterparty Amendment','Descripci�n del evento','A',null,null);
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('7','Partial Exercise','Descripci�n del evento','A',null,null);
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('10','Portfolio Assignment','Descripci�n del evento','A','Assignment','Portfolio Assignment');
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('11','Refresh','Descripci�n del evento','A','Modify','Refresh');
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('12','Restructure','Descripci�n del evento','A','Restructure','Amendment');
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('15','Unwind','Descripci�n del evento','A','Early Termination','Full Unwind');
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('16','Additional Flow Amendment','Descripci�n del evento','A',null,null);
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('17','Early Termination Total Return','Descripci�n del evento','A',null,null);
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('18','Exercise Cancellable','Descripci�n del evento','A',null,null);
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('19','Exercise Mutual Break','Descripci�n del evento','A',null,null);
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('20','Share Modification','Descripci�n del evento','A',null,null);
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('21','Early Termination','Descripci�n del evento','A',null,null);
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('23','Expiry','Descripci�n del evento','A','Expiry','NULL');
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('24','Cancel Event','Descripci�n del evento','A',null,null);
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('1','Insert','Descripci�n del evento','A','Insert','NULL');
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('6','Exercise','Descripci�n del evento','A','Exercise','NULL');
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('9','Modify UDF','Descripci�n del evento','A',null,null);
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('13','Step In','Descripci�n del evento','A',null,null);
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('14','Step Out','Descripci�n del evento','A',null,null);
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('22','Split','Descripci�n del evento','A',null,null);
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('25','Knock (in)','Descripci�n del evento','A','Early Termination','Knock');
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('8','Fixing','Descripci�n del evento','A','Fixing','NULL');
Insert into MUREX.EVENT (ID,NAME,DESCRIPTION,STATUS,ORIG_EVENT,EVENT_TYPE) values ('26','Cancel and Reissue Don''t Report','Descripci�n del evento','A','CancelReissue','Don''t Report');
COMMIT;
REM INSERTING into MUREX.EVENT_PRODUCT
SET DEFINE OFF;
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('4','1','4','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('20','6','1','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('1','1','1','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('5','1','5','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('6','1','6','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('7','1','7','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('8','1','8','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('11','1','11','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('12','1','12','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('13','1','13','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('14','1','14','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('15','1','15','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('16','1','16','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('17','1','17','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('18','1','18','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('19','1','19','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('21','6','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('23','6','5','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('24','6','9','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('25','6','6','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('28','6','10','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('30','6','12','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('31','6','13','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('32','6','14','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('34','6','16','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('35','6','17','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('36','6','18','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('37','6','19','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('38','23','1','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('39','23','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('40','23','3','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('41','23','4','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('42','23','5','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('43','23','9','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('44','23','6','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('45','23','7','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('51','23','14','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('54','23','17','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('57','3','1','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('59','3','3','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('60','3','4','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('61','3','5','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('62','3','9','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('63','3','6','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('64','3','7','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('65','3','8','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('66','3','10','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('67','3','11','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('68','3','12','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('69','3','13','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('70','3','14','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('71','3','15','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('72','3','16','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('73','3','17','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('74','3','18','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('2','1','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('3','1','3','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('9','1','9','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('10','1','10','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('22','6','4','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('46','23','8','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('47','23','10','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('48','23','11','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('49','23','12','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('50','23','13','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('52','23','15','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('53','23','16','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('55','23','18','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('56','23','19','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('58','3','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('75','3','19','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('77','15','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('78','15','3','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('79','15','4','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('80','15','5','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('81','15','9','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('84','15','8','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('85','15','10','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('86','15','11','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('87','15','12','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('88','15','13','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('89','15','14','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('90','15','15','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('91','15','16','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('92','15','17','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('93','15','18','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('94','15','19','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('95','4','1','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('96','4','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('97','4','3','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('98','4','4','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('99','4','5','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('100','4','9','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('101','4','6','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('102','4','7','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('103','4','8','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('104','4','10','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('105','4','11','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('106','4','12','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('107','4','13','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('108','4','14','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('109','4','15','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('110','4','16','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('111','4','17','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('112','4','18','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('113','4','19','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('114','12','1','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('124','12','11','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('125','12','12','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('126','12','13','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('127','12','14','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('128','12','15','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('129','12','16','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('130','12','17','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('131','12','18','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('132','12','19','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('133','2','1','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('134','2','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('135','2','3','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('136','2','4','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('137','2','5','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('138','2','9','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('139','2','6','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('140','2','7','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('141','2','8','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('142','2','10','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('143','2','11','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('144','2','12','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('145','2','13','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('146','2','14','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('147','2','15','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('148','2','16','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('149','2','17','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('150','2','18','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('151','2','19','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('152','10','1','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('153','10','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('154','10','3','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('155','10','4','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('156','10','5','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('169','10','18','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('170','10','19','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('171','11','1','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('172','11','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('173','11','3','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('174','11','4','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('175','11','5','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('176','11','9','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('177','11','6','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('178','11','7','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('179','11','8','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('180','11','10','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('181','11','11','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('182','11','12','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('183','11','13','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('184','11','14','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('185','11','15','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('186','11','16','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('187','11','17','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('188','11','18','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('189','11','19','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('191','25','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('192','25','3','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('26','6','7','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('27','6','8','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('29','6','11','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('33','6','15','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('76','15','1','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('82','15','6','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('83','15','7','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('115','12','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('116','12','3','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('117','12','4','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('118','12','5','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('119','12','9','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('120','12','6','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('121','12','7','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('122','12','8','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('123','12','10','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('157','10','9','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('158','10','6','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('159','10','7','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('160','10','8','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('161','10','10','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('162','10','11','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('163','10','12','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('164','10','13','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('165','10','14','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('166','10','15','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('167','10','16','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('168','10','17','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('190','25','1','A');
--Dont Report
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('193','26','1','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('194','26','2','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('195','26','3','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('196','26','4','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('197','26','5','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('198','26','6','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('199','26','7','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('200','26','8','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('201','26','9','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('202','26','10','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('203','26','11','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('204','26','12','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('205','26','13','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('206','26','14','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('207','26','15','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('208','26','16','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('209','26','17','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('210','26','18','A');
Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('211','26','19','A');

COMMIT;
REM INSERTING into MUREX.FAMILY
SET DEFINE OFF;
Insert into MUREX.FAMILY (ID,NAME,DESCRIPTION,STATUS) values (1,'CURR','Currency','A');
Insert into MUREX.FAMILY (ID,NAME,DESCRIPTION,STATUS) values (2,'EQD','Equity','A');
COMMIT;
REM INSERTING into MUREX.NAMESPACE
SET DEFINE OFF;
Insert into MUREX.NAMESPACE (ID,NAME,DESCRIPTION) values (1,'originating-event','Evento de origen');
Insert into MUREX.NAMESPACE (ID,NAME,DESCRIPTION) values (3,'trade-internal-id','Identificaci�n interna del trade');
Insert into MUREX.NAMESPACE (ID,NAME,DESCRIPTION) values (4,'trade-origin-id','Tipo de operaci�n');
Insert into MUREX.NAMESPACE (ID,NAME,DESCRIPTION) values (5,'contract-root-id','Tipo de operaci�n');
Insert into MUREX.NAMESPACE (ID,NAME,DESCRIPTION) values (6,'contract-origin-id','Tipo de operaci�n');
Insert into MUREX.NAMESPACE (ID,NAME,DESCRIPTION) values (7,'physical-status','Tipo de operaci�n');
Insert into MUREX.NAMESPACE (ID,NAME,DESCRIPTION) values (8,'product-type','Tipo de operaci�n');
Insert into MUREX.NAMESPACE (ID,NAME,DESCRIPTION) values (2,'operation-type','Tipo de operaci�n');
COMMIT;
REM INSERTING into MUREX.PRODUCT
SET DEFINE OFF;
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('6','CURR:OPT:FLEX','Forward Americano',null,'1','A','AMERICAN');
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('7','EQD:OPT:ASI','Opcion Asiatica de Equity',null,'2','A',null);
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('8','EQD:OPT:OTC','Opcion OTC de Equity',null,'2','A',null);
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('5','CURR:OPT:SMPS','Strip of simple Options',null,'1','A',null);
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('9','CURR:OPT:ASN','Asian Option',null,'1','A',null);
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('11','EQD:OPT:FLEX','Opci�n digital con varios pagos de cupones consolidables',null,'2','A','HimalayCn');
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('12','EQD:OPT:FLEX',null,null,'2','A','Mozart');
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('13','EQD:OPT:FLEX',null,null,'2','A','Cliquet');
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('14','EQD:OPT:FLEX',null,null,'2','A','Barrier_M');
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('15','EQD:OPT:FLEX',null,null,'2','A','AsianLB');
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('16','EQD:OPT:FLEX',null,null,'2','A','Ullyses');
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('17','EQD:OPT:FLEX',null,null,'2','A','AsianLock');
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('18','EQD:OPT:FLEX',null,null,'2','A','MTrigTarn');
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('19','EQD:OPT:FLEX',null,null,'2','A','BermDpPDE ');
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('1','CURR:OPT:BAR','Simple Barrier',null,'1','A',null);
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('2','CURR:OPT:BAR2','Double Barrier',null,'1','A',null);
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('3','CURR:OPT:RBT','Touch rebate',null,'1','A',null);
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('4','CURR:OPT:SMP','Simple Option',null,'1','A',null);
Insert into MUREX.PRODUCT (ID,CODE,DESCRIPTION,ID_PRODCUT_OWNER,ID_FAMILY,STATUS,FLEX) values ('10','EQD:OPT:FLEX','Flex Padre Equity',null,'2','A','NMxMnDig');
COMMIT;
REM INSERTING into MUREX.RULES
SET DEFINE OFF;
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (5,'ROOT','MUREX31','1',null);
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (6,'ROOT','MUREX31','2',null);
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (7,'GENERICHEADER','MUREX31','3',null);
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (8,'GENERICHEADER','MUREX31','4','3');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (9,'GENERICHEADER','MUREX31','5','4');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (10,'GENERICHEADER','MUREX31','6','4');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (11,'GENERICHEADER','MUREX31','7','4');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (14,'INSERT','MUREX31','8',null);
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (12,'INSERT','MUREX31','9','8');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (8,'INSERT','MUREX31','10','9');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (13,'INSERT','MUREX31','11','10');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (14,'PRODUCTCATEGORY','MUREX31','12',null);
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (12,'PRODUCTCATEGORY','MUREX31','13','12');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (15,'PRODUCTCATEGORY','MUREX31','14','13');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (16,'PRODUCTCATEGORY','MUREX31','15','14');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (17,'PRODUCTCATEGORY','MUREX31','16','15');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (18,'PRODUCTCATEGORY','MUREX31','17','15');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (19,'PRODUCTCATEGORY','MUREX31','18','15');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (14,'OPT|RBT|FX Touch rebate','MUREX31','19',null);
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (20,'OPT|RBT|FX Touch rebate','MUREX31','20','19');
Insert into MUREX.RULES (ID_TAG,PERFIL,SERVICE_CODE,ID,ID_RULE_OWNER) values (21,'OPT|RBT|FX Touch rebate','MUREX31','21','20');
COMMIT;
REM INSERTING into MUREX.TAG
SET DEFINE OFF;
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (1,'originatingEvent','Evento de origen','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (2,'operationType','Tipo de operaci�n','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (3,'eventType','Tipo de evento','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (4,'primaryAssetClass','Familia del producto','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (5,'executionNotification','Root execution notification','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (6,'executionRetracted','Root exeuction retracted (CANCEL)','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (7,'header','Cabecera','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (9,'originatingEvent','Evento de origen','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (11,'eventType','Tipo de Evento','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (8,'partyMessageInformation','Party message information','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (10,'operationType','Tipo de Operaci�n','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (12,'tradeHeader','Cabecera del Trade','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (13,'entity','Entidad','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (14,'trade','Trade','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (15,'partyTradeInformation','Informaci�n de la partida del Trade','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (16,'productCategory','Categor�a del producto','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (17,'group','Grupo','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (18,'type','Tipo','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (19,'typology','Tipolog�a','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (20,'fxDigitalOption','Fx Digital Option','A');
Insert into MUREX.TAG (ID,NAME,DESCRIPTION,STATUS) values (21,'primaryAssetClass','Familia','A');
COMMIT;
REM INSERTING into MUREX.TRANSACTION_LOG
SET DEFINE OFF;
REM INSERTING into PARAMETERS_GENERIC
SET DEFINE OFF;
Insert into MUREX.PARAMETERS_GENERIC (ID,FIELD,VALUE,STATUS,SERVICE) values ('1','CURROPTBAR','QL.MX3.CURROPTBAR.RQ','A','10302');
Insert into MUREX.PARAMETERS_GENERIC (ID,FIELD,VALUE,STATUS,SERVICE) values ('2','CURROPTRBT','QL.MX3.CURROPTRBT.RQ','A','10302');
Insert into MUREX.PARAMETERS_GENERIC (ID,FIELD,VALUE,STATUS,SERVICE) values ('3','CURROPTSMP','QL.MX3.CURROPTSMP.RQ','A','10302');
Insert into MUREX.PARAMETERS_GENERIC (ID,FIELD,VALUE,STATUS,SERVICE) values ('4','CURROPTSMPS','QL.MX3.CURROPTSMPS.RQ','A','10302');
Insert into MUREX.PARAMETERS_GENERIC (ID,FIELD,VALUE,STATUS,SERVICE) values ('5','CURROPTFLEX','QL.MX3.CURROPTFLEX.RQ','A','10302');
Insert into MUREX.PARAMETERS_GENERIC (ID,FIELD,VALUE,STATUS,SERVICE) values ('6','CURROPTASN','QL.MX3.CURROPTASN.RQ','A','10302');
Insert into MUREX.PARAMETERS_GENERIC (ID,FIELD,VALUE,STATUS,SERVICE) values ('7','EQDOPTFLEX','QL.MX3.EQDOPTFLEX.RQ','A','10302');
Insert into MUREX.PARAMETERS_GENERIC (ID,FIELD,VALUE,STATUS,SERVICE) values ('8','EQDOPTASI','QL.MX3.EQDOPTASI.RQ','A','10302');
Insert into MUREX.PARAMETERS_GENERIC (ID,FIELD,VALUE,STATUS,SERVICE) values ('9','EQDOPTOTC','QL.MX3.EQDOPTOTC.RQ','A','10302');
Insert into MUREX.PARAMETERS_GENERIC (ID,FIELD,VALUE,STATUS,SERVICE) values ('10','VALUE_ENTITY','BBVACONTI','A','10302');
COMMIT;
--------------------------------------------------------
--  DDL for Index EVENT_PRODUCT_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "MUREX"."EVENT_PRODUCT_PK" ON "MUREX"."EVENT_PRODUCT" ("ID");
--------------------------------------------------------
--  DDL for Index RULES_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "MUREX"."RULES_PK" ON "MUREX"."RULES" ("ID");
--------------------------------------------------------
--  DDL for Index PRODUCT_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "MUREX"."PRODUCT_PK" ON "MUREX"."PRODUCT" ("ID");
--------------------------------------------------------
--  DDL for Index TRANSACTION_LOG_PK
--------------------------------------------------------

  CREATE UNIQUE INDEX "MUREX"."TRANSACTION_LOG_PK" ON "MUREX"."TRANSACTION_LOG" ("ID");
--------------------------------------------------------
--  DDL for Package PKG_MUREX_DELETE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "MUREX"."PKG_MUREX_DELETE" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  -- Modificado por Jorge Prado : 14:28
  PROCEDURE SP_DELETE_MESSAGE (pii_dif_day IN INT,
                             pov_code_resp OUT VARCHAR2,
                             pov_msg_resp OUT VARCHAR2);
  

END "PKG_MUREX_DELETE";

/
--------------------------------------------------------
--  DDL for Package PKG_MUREX_INS_UPDT
--------------------------------------------------------

--------------------------------------------------------
--  DDL for Package PKG_MUREX_INS_UPDT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "MUREX"."PKG_MUREX_INS_UPDT" AS 

  PROCEDURE sp_update_status_msg (piv_message_id IN transaction_log.message_id%TYPE, 
                                  piv_status IN transaction_log.status%TYPE,
                                  piv_status_description IN transaction_log.status_description%TYPE,
                                  pov_code_resp OUT VARCHAR2,
                                  pov_msg_resp OUT VARCHAR2);
  
  PROCEDURE sp_register_log (piv_id_audit_hub IN transaction_log.id_audit_hub%TYPE, 
                             picb_content IN transaction_log.content_xml%TYPE, 
                             pov_code_resp OUT VARCHAR2, 
                             pov_msg_resp OUT VARCHAR2);
    
  PROCEDURE sp_update_log (piv_id_audit_hub IN transaction_log.id_audit_hub%TYPE, 
                           piv_message_id IN transaction_log.message_id%TYPE, 
                           piv_orig_event IN transaction_log.orig_event%TYPE,
                           piv_trade_id IN transaction_log.trade_id%TYPE,
                           piv_event_type IN transaction_log.event_type%TYPE,
                           piv_contract_id IN transaction_log.contract_id%TYPE,
                           piv_trade_status IN transaction_log.trade_status%TYPE,
                           piv_trade_date IN transaction_log.trade_date%TYPE,
                           pic_trade_version IN transaction_log.trade_version%TYPE,
                           piv_product IN transaction_log.product%TYPE,
                           pic_status IN transaction_log.status%TYPE,
                           pov_code_resp OUT VARCHAR2, 
                           pov_msg_resp OUT VARCHAR2);                          

END PKG_MUREX_INS_UPDT;

/
--------------------------------------------------------
--  DDL for Package PKG_MUREX_READ
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE "MUREX"."PKG_MUREX_READ" AS 

  /* TODO enter package declarations (types, exceptions, methods etc) here */ 
  PROCEDURE sp_check_contract(
    contractid IN VARCHAR2, 
    check_out OUT int);
  
  PROCEDURE sp_check_trade(
    tradeid IN VARCHAR2, 
    check_out OUT int);
    
  PROCEDURE sp_show_events (
    servicecode IN VARCHAR, 
    listaeventoprod OUT SYS_REFCURSOR);
    
  PROCEDURE sp_check_unique (
      event IN transaction_log.orig_event%TYPE, 
      contractid IN transaction_log.contract_id%TYPE,
      tradeid IN transaction_log.trade_id%TYPE,
      tradeversion IN transaction_log.trade_version%TYPE,
      check_out OUT int);
      
  PROCEDURE sp_mostrar_parametronegocio (
        servicecode IN VARCHAR,
        listaparametronegocio OUT   SYS_REFCURSOR);
        
  PROCEDURE sp_check_event_start (
    contractid IN transaction_log.contract_id%TYPE,
    check_out OUT int);
    
  PROCEDURE sp_show_pending (
        pi_contractid IN transaction_log.contract_id%TYPE, 
        po_listpending OUT SYS_REFCURSOR);
 
  PROCEDURE sp_list_parameters_generic (
    servicecode IN VARCHAR, 
    listparameters OUT SYS_REFCURSOR);

END PKG_MUREX_READ;

/
--------------------------------------------------------
--  DDL for Package Body PKG_MUREX_DELETE
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "MUREX"."PKG_MUREX_DELETE" 
AS

  ------------------------------------------------------------------------------
  --  PROCEDURE NAME  : SP_DELETE_MESSAGE
  --  DESCRIPTION     : PROCEDIMIENTO QUE DEPURA LOS MESAJES BAJO DETERMINADO
  --                    CRITERIO PARA FILTRAR LOS MAS ANTIGUOS Y SIN MOVIMIENTOS.
  --  AUTOR           : JORGE PRADO
  --  CREATE          : 30/10/2020
  --  UPDATE          :
  --  VERSION         : 1.0
  ------------------------------------------------------------------------------
  PROCEDURE SP_DELETE_MESSAGE (pii_dif_day IN INT,
                             pov_code_resp OUT VARCHAR2,
                             pov_msg_resp OUT VARCHAR2) 
  IS
CURSOR c_LastMessage IS
        SELECT T1.CONTRACT_ID, COUNT(1) AS TOT_MSG, MAX(T1.TRADE_DATE) AS TRADE_DATE_MAX 
        FROM TRANSACTION_LOG T1  
        GROUP BY T1.CONTRACT_ID;
  
    r_LastMessage c_LastMessage%ROWTYPE;
    
    V_CONTRACT_ID VARCHAR2(100);
    V_TRADE_DATE_MAX VARCHAR2(100);
    V_TRADE_STATUS VARCHAR2(4) := 'dead';
    I_DIFERENCIA_DIAS INT;
    
  BEGIN
    
    OPEN c_LastMessage;
    LOOP
      
      FETCH c_LastMessage INTO r_LastMessage;
      EXIT WHEN c_LastMessage%NOTFOUND;
      V_TRADE_DATE_MAX := '';
      I_DIFERENCIA_DIAS := 0;
      BEGIN
          SELECT T1.TRADE_DATE 
          INTO V_TRADE_DATE_MAX 
          FROM TRANSACTION_LOG T1 
          WHERE T1.CONTRACT_ID = r_LastMessage.CONTRACT_ID 
          AND T1.TRADE_DATE = r_LastMessage.TRADE_DATE_MAX 
          AND T1.TRADE_STATUS = V_TRADE_STATUS;
          
      EXCEPTION
        WHEN NO_DATA_FOUND THEN
          V_TRADE_DATE_MAX := '';            
        WHEN OTHERS THEN
          V_TRADE_DATE_MAX := '';          
      END;
    
      IF V_TRADE_DATE_MAX IS NOT NULL THEN
        --- VALIDAR LA DIFERENCIA DE DIAS, SEGUN FECHA DEL MENSAJES
        I_DIFERENCIA_DIAS := ROUND(sysdate - TO_DATE(SUBSTR(r_LastMessage.TRADE_DATE_MAX,1,10), 'YYYY-MM-DD'));        
        --- VALIDAR LOS N DIAS
        IF I_DIFERENCIA_DIAS > pii_dif_day THEN
            --- ELIMINAR LOS MENSAJES DEL "CONTRACT ROOT ID"
            DELETE FROM TRANSACTION_LOG WHERE CONTRACT_ID = r_LastMessage.CONTRACT_ID;            
        END IF;
      END IF;
      
    
    END LOOP;
    CLOSE c_LastMessage;
    COMMIT;
    pov_code_resp := '0';
    pov_msg_resp := 'PROCESO EXITOSO';
    
   EXCEPTION 
    WHEN OTHERS THEN
        pov_code_resp := '-1';
        pov_msg_resp := SQLCODE || ' - ERROR AL EJECUTAR [SP_DELETE_MESSAGE] - ' || SQLERRM;   
  END SP_DELETE_MESSAGE;

END "PKG_MUREX_DELETE";

/
--------------------------------------------------------
--  DDL for Package Body PKG_MUREX_INS_UPDT
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "MUREX"."PKG_MUREX_INS_UPDT" AS
--SP que actualiza el estado del mensaje
  PROCEDURE sp_update_status_msg (piv_message_id IN transaction_log.message_id%TYPE, 
                                  piv_status IN transaction_log.status%TYPE,
                                  piv_status_description IN transaction_log.status_description%TYPE,
                                  pov_code_resp OUT VARCHAR2,
                                  pov_msg_resp OUT VARCHAR2) AS 
  BEGIN
    UPDATE TRANSACTION_LOG
    SET STATUS = piv_status,
    STATUS_DESCRIPTION = piv_status_description
    WHERE MESSAGE_ID = piv_message_id;  
    COMMIT;
    pov_code_resp := SQLCODE;
    pov_msg_resp := 'ACTUALIZACION EXITOSA';
  EXCEPTION 
    WHEN OTHERS THEN
        pov_code_resp := SQLCODE;
        pov_msg_resp := 'ERROR AL EJECUTAR [sp_update_status_msg] - ' || SQLERRM;
  END sp_update_status_msg;
  
  --SP que salvaguarda el mensaje(XML) y el campo id_audit_hub en la tabla TRANSACTION_LOG 
  PROCEDURE sp_register_log (piv_id_audit_hub IN transaction_log.id_audit_hub%type, 
                             picb_content IN transaction_log.content_xml%type, 
                             pov_code_resp OUT VARCHAR2, 
                             pov_msg_resp OUT VARCHAR2) AS
  BEGIN
    INSERT INTO TRANSACTION_LOG (ID_AUDIT_HUB, 
                                 CONTENT_XML)
    VALUES (piv_id_audit_hub, 
            picb_content);
    COMMIT;
    pov_code_resp := SQLCODE;
    pov_msg_resp := 'REGISTRO EXITOSO';
  EXCEPTION 
        WHEN OTHERS THEN
            pov_code_resp := SQLCODE;
            pov_msg_resp := 'ERROR AL EJECUTAR [sp_register_new] - ' || SQLERRM;
  END sp_register_log;
  
  
  --SP que actualiza la tabla del mensaje con sus campos adicionales, basandose
  --en el campo ID_AUDIT_HUB, guardado previamente con sp_register_log.
  PROCEDURE sp_update_log (piv_id_audit_hub IN transaction_log.id_audit_hub%type,
                           piv_message_id IN transaction_log.message_id%type, 
                           piv_orig_event IN transaction_log.orig_event%type,
                           piv_trade_id IN transaction_log.trade_id%type,
                           piv_event_type IN transaction_log.event_type%type,
                           piv_contract_id IN transaction_log.contract_id%type,
                           piv_trade_status IN transaction_log.trade_status%type,
                           piv_trade_date IN transaction_log.trade_date%type,
                           pic_trade_version IN transaction_log.trade_version%type,
                           piv_product IN transaction_log.product%type,
                           pic_status IN transaction_log.status%type,
                           pov_code_resp OUT VARCHAR2, 
                           pov_msg_resp OUT VARCHAR2) AS 
  BEGIN
    UPDATE TRANSACTION_LOG
    SET MESSAGE_ID = piv_message_id,
        ORIG_EVENT = piv_orig_event,
        TRADE_ID = piv_trade_id,
        EVENT_TYPE = piv_event_type,
        CONTRACT_ID = piv_contract_id,
        TRADE_STATUS = piv_trade_status,
        TRADE_DATE = piv_trade_date,
        TRADE_VERSION = pic_trade_version,
        PRODUCT = piv_product,
        STATUS = pic_status
    WHERE ID_AUDIT_HUB = piv_id_audit_hub;  
    COMMIT;
    pov_code_resp := SQLCODE;
    pov_msg_resp := 'ACTUALIZACION EXITOSA';
  EXCEPTION 
    WHEN OTHERS THEN
        pov_code_resp := SQLCODE;
        pov_msg_resp := 'ERROR AL EJECUTAR [sp_update_log] - ' || SQLERRM;
  END sp_update_log;  

END PKG_MUREX_INS_UPDT;

/
--------------------------------------------------------
--  DDL for Package Body PKG_MUREX_READ
--------------------------------------------------------

  CREATE OR REPLACE PACKAGE BODY "MUREX"."PKG_MUREX_READ" AS

  PROCEDURE sp_check_contract(contractid IN VARCHAR2, check_out OUT int) AS
  total int;
  BEGIN
    SELECT COUNT(CONTRACT_ID) into total FROM TRANSACTION_LOG WHERE CONTRACT_ID = contractid;
    -- necesitaremos el conteo ?
    if total != 0 then
    check_out := 0;
    else
    check_out := 1;
    end if; 
  END sp_check_contract;

  PROCEDURE sp_check_trade(tradeid IN VARCHAR2, check_out OUT int) AS
  total int;
  BEGIN
    SELECT COUNT(TRADE_ID) into total FROM TRANSACTION_LOG WHERE TRADE_ID = tradeid;
    -- necesitaremos el conteo ?
    if total != 0 then
    check_out := 0;
    else
    check_out := 1;
    end if; 
  END sp_check_trade;
  
  PROCEDURE sp_show_events (servicecode IN VARCHAR, listaeventoprod OUT SYS_REFCURSOR) AS
  BEGIN
   OPEN listaeventoprod
   FOR SELECT
            E.ORIG_EVENT, E.EVENT_TYPE, LISTAGG(CONCAT(CONCAT(P.CODE,':'),P.FLEX), '|') WITHIN GROUP (ORDER BY EP.ID) AS PRODUCTS 
    FROM EVENT_PRODUCT EP 
    JOIN PRODUCT P ON EP.ID_PRODUCT = P.ID
    JOIN EVENT E ON EP.ID_EVENT = E.ID
    WHERE EP.STATUS = 'A'
    GROUP BY E.ORIG_EVENT, E.EVENT_TYPE;

    EXCEPTION
        WHEN OTHERS THEN
            raise_application_error(-20299, '1&');
  END sp_show_events;
  
  
  --Obtiene la cantidad de mensajes registrados previamente en la
  --tabla TRANSACTION_LOG por el campo CONTRACT_ID,TRADE_ID,TRADE_VERSION
  PROCEDURE sp_check_unique (
      event IN transaction_log.orig_event%TYPE, 
      contractid IN transaction_log.contract_id%TYPE,
      tradeid IN transaction_log.trade_id%TYPE,
      tradeversion IN transaction_log.trade_version%TYPE,
      check_out OUT int) AS
      BEGIN
      
      SELECT COUNT(CONTRACT_ID) INTO check_out FROM 
      TRANSACTION_LOG WHERE 
        ORIG_EVENT = event
        AND CONTRACT_ID = contractid
        AND TRADE_ID = tradeid
        AND TRADE_VERSION = tradeversion;
        
   END sp_check_unique;

  PROCEDURE sp_mostrar_parametronegocio (
        servicecode IN VARCHAR,
        listaparametronegocio OUT   SYS_REFCURSOR
    ) AS
    BEGIN
        OPEN listaparametronegocio 
            FOR SELECT
                r.id,
                t.name,
                r.id_rule_owner,
                r.perfil
                    FROM
                    rules r
                    JOIN tag t ON r.id_tag = t.id
                    WHERE r.service_code = servicecode;

    EXCEPTION
        WHEN OTHERS THEN
            raise_application_error(-20299, '1&');
    END sp_mostrar_parametronegocio;

    PROCEDURE sp_check_event_start (
        contractid IN transaction_log.contract_id%TYPE,
        check_out OUT int) AS
        BEGIN
        
        SELECT COUNT(CONTRACT_ID) into check_out from transaction_log where 
        ORIG_EVENT ='Insert' and EVENT_TYPE IS NULL OR (ORIG_EVENT = 'Modify' and EVENT_TYPE = 'Refresh') and status = 'SEND' 
        AND CONTRACT_ID = contractid; 
        
        END sp_check_event_start;
    
    --OBTIENE EL LISTADO DE EVENTOS EN ESTADO PENDIENTE
    PROCEDURE sp_show_pending (
        pi_contractid IN transaction_log.contract_id%TYPE, 
        po_listpending OUT SYS_REFCURSOR) AS
        BEGIN 
        
        OPEN po_listpending
            FOR SELECT MESSAGE_ID, CONTENT_XML FROM 
            TRANSACTION_LOG 
            WHERE CONTRACT_ID = pi_contractid AND status = 'PENDING' 
            AND ORIG_EVENT <> 'Insert' AND ORIG_EVENT <> 'Modify' 
            ORDER BY TRADE_VERSION, TRADE_DATE;

    EXCEPTION
        WHEN OTHERS THEN
            raise_application_error(-20299, '1&');
    END sp_show_pending;
    
    -- Author: Anthonny Caro
    -- Lista parametros genericos : Las colas de cada producto
    PROCEDURE sp_list_parameters_generic (
        servicecode IN VARCHAR, 
        listparameters OUT SYS_REFCURSOR) AS
    BEGIN
        OPEN listparameters
            FOR SELECT
                PG.FIELD, PG.VALUE
        FROM PARAMETERS_GENERIC PG 
        WHERE PG.SERVICE = servicecode AND PG.STATUS = 'A';
    EXCEPTION
        WHEN OTHERS THEN
            raise_application_error(-20299, '1&');
    END sp_list_parameters_generic;
    
END PKG_MUREX_READ;

/
--------------------------------------------------------
--  Constraints for Table PRODUCT
--------------------------------------------------------

  ALTER TABLE "MUREX"."PRODUCT" ADD CONSTRAINT "PRODUCT_PK" PRIMARY KEY ("ID");
  ALTER TABLE "MUREX"."PRODUCT" MODIFY ("ID_FAMILY" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."PRODUCT" MODIFY ("CODE" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."PRODUCT" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table NAMESPACE
--------------------------------------------------------

  ALTER TABLE "MUREX"."NAMESPACE" ADD PRIMARY KEY ("ID");
  ALTER TABLE "MUREX"."NAMESPACE" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table RULES
--------------------------------------------------------

  ALTER TABLE "MUREX"."RULES" ADD CONSTRAINT "RULES_PK" PRIMARY KEY ("ID");
  ALTER TABLE "MUREX"."RULES" MODIFY ("PERFIL" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."RULES" MODIFY ("ID_TAG" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."RULES" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table FAMILY
--------------------------------------------------------

  ALTER TABLE "MUREX"."FAMILY" ADD PRIMARY KEY ("ID");
  ALTER TABLE "MUREX"."FAMILY" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TAG
--------------------------------------------------------

  ALTER TABLE "MUREX"."TAG" ADD PRIMARY KEY ("ID");
  ALTER TABLE "MUREX"."TAG" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."TAG" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table TRANSACTION_LOG
--------------------------------------------------------

  ALTER TABLE "MUREX"."TRANSACTION_LOG" MODIFY ("ID_AUDIT_HUB" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."TRANSACTION_LOG" MODIFY ("CONTENT_XML" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."TRANSACTION_LOG" MODIFY ("REG_DATE" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."TRANSACTION_LOG" ADD CONSTRAINT "TRANSACTION_LOG_PK" PRIMARY KEY ("ID");
--------------------------------------------------------
--  Constraints for Table EVENT
--------------------------------------------------------

  ALTER TABLE "MUREX"."EVENT" ADD PRIMARY KEY ("ID");
  ALTER TABLE "MUREX"."EVENT" MODIFY ("DESCRIPTION" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."EVENT" MODIFY ("NAME" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."EVENT" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table AUDIT_ERROR
--------------------------------------------------------

  ALTER TABLE "MUREX"."AUDIT_ERROR" ADD PRIMARY KEY ("ID");
  ALTER TABLE "MUREX"."AUDIT_ERROR" MODIFY ("TRADEID" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."AUDIT_ERROR" MODIFY ("ORIGEVENT" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."AUDIT_ERROR" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Constraints for Table EVENT_PRODUCT
--------------------------------------------------------

  ALTER TABLE "MUREX"."EVENT_PRODUCT" ADD CONSTRAINT "EVENT_PRODUCT_PK" PRIMARY KEY ("ID");
  ALTER TABLE "MUREX"."EVENT_PRODUCT" MODIFY ("STATUS" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."EVENT_PRODUCT" MODIFY ("ID_PRODUCT" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."EVENT_PRODUCT" MODIFY ("ID_EVENT" NOT NULL ENABLE);
  ALTER TABLE "MUREX"."EVENT_PRODUCT" MODIFY ("ID" NOT NULL ENABLE);
--------------------------------------------------------
--  Ref Constraints for Table EVENT_PRODUCT
--------------------------------------------------------

  ALTER TABLE "MUREX"."EVENT_PRODUCT" ADD CONSTRAINT "FK_EVENT_PRODUCT_EVENT" FOREIGN KEY ("ID_EVENT")
	  REFERENCES "MUREX"."EVENT" ("ID") ENABLE;
  ALTER TABLE "MUREX"."EVENT_PRODUCT" ADD CONSTRAINT "FK_EVENT_PRODUCT_PRODUCT" FOREIGN KEY ("ID_PRODUCT")
	  REFERENCES "MUREX"."PRODUCT" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table PRODUCT
--------------------------------------------------------

  ALTER TABLE "MUREX"."PRODUCT" ADD CONSTRAINT "FK_P_F" FOREIGN KEY ("ID_FAMILY")
	  REFERENCES "MUREX"."FAMILY" ("ID") ENABLE;
--------------------------------------------------------
--  Ref Constraints for Table RULES
--------------------------------------------------------

  ALTER TABLE "MUREX"."RULES" ADD CONSTRAINT "FK_RULES_OWNER" FOREIGN KEY ("ID_RULE_OWNER")
	  REFERENCES "MUREX"."RULES" ("ID") ENABLE;
  ALTER TABLE "MUREX"."RULES" ADD CONSTRAINT "FK_RULES_TAG" FOREIGN KEY ("ID_TAG")
	  REFERENCES "MUREX"."TAG" ("ID") DISABLE;
--------------------------------------------------------
--  Grant TABLE
--------------------------------------------------------
grant select, insert, update, delete on MUREX.AUDIT_ERROR       to APP_MUREX; 
grant select, insert, update, delete on MUREX.EVENT             to APP_MUREX; 
grant select, insert, update, delete on MUREX.EVENT_PRODUCT     to APP_MUREX; 
grant select, insert, update, delete on MUREX.FAMILY            to APP_MUREX; 
grant select, insert, update, delete on MUREX.NAMESPACE         to APP_MUREX; 
grant select, insert, update, delete on MUREX.PRODUCT           to APP_MUREX; 
grant select, insert, update, delete on MUREX.RULES             to APP_MUREX; 
grant select, insert, update, delete on MUREX.TAG               to APP_MUREX; 
grant select, insert, update, delete on MUREX.TRANSACTION_LOG   to APP_MUREX; 
grant select, insert, update, delete on MUREX.PARAMETERS_GENERIC to APP_MUREX; 
--------------------------------------------------------
--  Grant PACKAGE
--------------------------------------------------------	  
grant execute on MUREX.PKG_MUREX_DELETE 		to APP_MUREX;
grant execute on MUREX.PKG_MUREX_INS_UPDT 	to APP_MUREX;
grant execute on MUREX.PKG_MUREX_READ 		to APP_MUREX;
--------------------------------------------------------
--  Grant PROCEDIMIENTOS
--------------------------------------------------------
--grant execute on MUREX.PKG_MUREX_DELETE.SP_DELETE_MESSAGE		to APP_MUREX; 
--grant execute on MUREX.sp_update_status_msg     to APP_MUREX; 
--grant execute on MUREX.sp_register_log          to APP_MUREX; 
--grant execute on MUREX.sp_update_log            to APP_MUREX; 
--grant execute on MUREX.sp_check_contract        to APP_MUREX; 
--grant execute on MUREX.sp_check_trade           to APP_MUREX; 
--grant execute on MUREX.sp_show_events           to APP_MUREX; 
--grant execute on MUREX.sp_check_unique          to APP_MUREX; 
--grant execute on MUREX.sp_mostrar_parametronegocio   to APP_MUREX; 
--grant execute on MUREX.sp_check_event_start          to APP_MUREX; 
--grant execute on MUREX.sp_show_pending               to APP_MUREX; 
--grant execute on MUREX.sp_list_parameters_generic    to APP_MUREX; 

