Insert into MUREX.EVENT_PRODUCT (ID,ID_EVENT,ID_PRODUCT,STATUS) values ('281','28','21','A');
commit;