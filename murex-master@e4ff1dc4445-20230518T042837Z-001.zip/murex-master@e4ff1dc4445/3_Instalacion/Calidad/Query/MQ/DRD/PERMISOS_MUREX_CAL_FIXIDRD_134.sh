setmqaut -m CMDW2 -n QLC.MX3.FIXIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
setmqaut -m CMDW2 -n QL.MX3.FIXIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
