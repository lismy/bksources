setmqaut -m CMDW1 -n QLC.MX3.FIXIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
setmqaut -m CMDW1 -n QL.MX3.FIXIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;



