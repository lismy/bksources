setmqaut -m CMDW1 -n QLC.MX3.FEESIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
setmqaut -m CMDW1 -n QL.MX3.FEESIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;


