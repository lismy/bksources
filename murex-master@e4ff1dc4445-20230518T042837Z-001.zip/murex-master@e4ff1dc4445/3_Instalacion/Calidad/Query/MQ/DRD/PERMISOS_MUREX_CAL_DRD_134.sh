setmqaut -m CMDW2 -n QLC.MX3.FEESIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
setmqaut -m CMDW2 -n QL.MX3.FEESIRDLNBR.RQ -t queue -p aceapp +put +get +inq +passall +browse;
