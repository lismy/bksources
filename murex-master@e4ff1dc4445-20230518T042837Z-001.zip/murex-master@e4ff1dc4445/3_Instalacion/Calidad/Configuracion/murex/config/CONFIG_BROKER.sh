#!/bin/bash
work_dir=$1
mqsisetdbparms -w /opt/IBM/ace-11.0.0.11/server/workdir/$work_dir/ -n APP_HUBACE -u APP_HUBACE  -p ##########
mqsisetdbparms -w /opt/IBM/ace-11.0.0.11/server/workdir/$work_dir/ -n MUREX -u MUREX  -p ##########

