#!/bin/bash
pod=$2
rm -rf $pod.properties
